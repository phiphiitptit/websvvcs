<?php 
echo'
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
<div class="sidebar-sticky pt-3">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link active" href="teacher_dasboard.php">
                <span class="iconify" data-icon="bi:file-person" data-inline="false"></span>
                Danh sách người dùng <span class="sr-only">(current)</span>
            </a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" href="homework.php">
            <span class="iconify" data-icon="bi-file-earmark-binary" data-inline="false"></span>
            Quản lý bài tập <span class="sr-only">(current)</span>
        </a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" href="chatmessage.php">
            <span class="iconify" data-icon="bi-chat-dots" data-inline="false"></span>
            Tin nhắn <span class="sr-only">(current)</span>
        </a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" href="challenge.php">
            <span class="iconify" data-icon="bi-patch-question" data-inline="false"></span>
            Challenge <span class="sr-only">(current)</span>
        </a>
        </li>
        <li class="nav-item">
        <a class="nav-link active" href="edit_info.php">
            <span class="iconify" data-icon="bi-bug-fill" data-inline="false"></span>
            Chỉnh sửa thông tin <span class="sr-only">(current)</span>
        </a>
        </li>
    </ul>
</div>
</nav>';
?>